import React from 'react'

const ViewProfile = () => {
  return (
    <div>ViewProfile</div>
  )
}

export default ViewProfile