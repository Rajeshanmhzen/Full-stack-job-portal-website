import React from 'react'

const SavedJobs = () => {
  return (
    <div>SavedJobs</div>
  )
}

export default SavedJobs