import React from 'react'

const Profile = () => {
  return (
    <div>
        pprofile
    </div>
  )
}

export default Profile