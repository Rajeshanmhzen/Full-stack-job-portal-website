import React from 'react'

const TalentCard = () => {
  return (
    <div>
        
    </div>
  )
}

export default TalentCard