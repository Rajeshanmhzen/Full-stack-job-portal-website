import { notifications } from "@mantine/notifications";
import {useEffect,  useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { COMPANY_API_END_POINT } from "../../utils/constant";
import axios from "axios";
import { Button, FileInput, Textarea, TextInput } from "@mantine/core";
import {useSelector} from "react-redux"


const AddCompanyDetails = () => {
  const {singleCompany} = useSelector(store=> store.company)
 const navigate = useNavigate();
  const { id } = useParams();
  const [loading, setLoading] = useState("")
  const [formData, setFormData] = useState({
    logo:"",
    name: "",
    email: "",
    website: "",
    location: "",
    description: "",
  });
   const handleUpdate = async () => {
    try {
      setLoading(true);
      const data = new FormData();
    if (formData.logo) data.append("logo", formData.logo);
    data.append("name", formData.name);
    data.append("email", formData.email);
    data.append("website", formData.website);
    data.append("location", formData.location);
    data.append("description", formData.description);
      const res = await axios.put(
        `${COMPANY_API_END_POINT}/update/${id}`,
        data,
        { withCredentials: true,
          headers: {
          "Content-Type": "multipart/form-data",
        },
         },
       
      );
      if(res.data.success) {
          notifications.show({
              title: "Success",
              message: "Company updated successfully",
              color: "green",
            });
            setTimeout(()=> {
                navigate("/company")
            }, 1000)
        }
    } catch (err) {
      notifications.show({
        title: "Update Failed",
        message: err?.response?.data?.message || "Something went wrong",
        color: "red",
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(()=> {
    setFormData({
      logo:singleCompany.logo ||null,
    name: singleCompany.name ||"",
    email: singleCompany.email ||"",
    website: singleCompany.website ||"",
    location: singleCompany.location ||"",
    description: singleCompany.description ||"",
    })
  },[singleCompany])
  return (
    <div className="w-1/2 shadow-sm shadow-purple-heart-700 px-5 py-5 rounded-sm mx-auto">
        <form className="flex flex-col gap-2 ">
                          <FileInput clearable label="Upload company logo" placeholder="Upload logo" value={formData.logo}  onChange={(file)=> setFormData({...formData, logo:file})}/>
                          <TextInput
                            label="Name"
                            value={formData.name}
                            onChange={(e) =>
                              setFormData({ ...formData, name: e.target.value })
                            }
                          />
                          <TextInput
                            label="Email"
                            value={formData.email}
                            onChange={(e) =>
                              setFormData({ ...formData, email: e.target.value })
                            }
                          />
                          <TextInput
                            label="Website"
                            value={formData.website}
                            onChange={(e) =>
                              setFormData({ ...formData, website: e.target.value })
                            }
                          />
                          <TextInput
                            label="Location"
                            value={formData.location}
                            onChange={(e) =>
                              setFormData({ ...formData, location: e.target.value })
                            }
                          />
                          <Textarea
                            label="Description"
                            minRows={2}
                            value={formData.description}
                            onChange={(e) =>
                              setFormData({ ...formData, description: e.target.value })
                            }
                          />
                          <Button
                            className="bg-purple-heart-500 hover:bg-purple-heart-600 mt-2"
                            onClick={handleUpdate}
                            disabled={loading}
                          >
                            {loading ? <Loader size="xs" /> : "Save Changes"}
                          </Button>
                        </form>
    </div>
  )
}

export default AddCompanyDetails