import express from "express";
import { searchCandidates } from "../controllers/user/user.controller.js";
import { searchjobs } from "../controllers/job/job.controller.js";
import Authtoken from "../middleware/authtoken.js";

const router = express.Router();

router.get("/jobs", searchjobs); // Open to all
router.get("/candidates", Authtoken, searchCandidates); // Only for recruiters

export default router;