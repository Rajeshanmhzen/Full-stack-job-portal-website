import  Job  from "../../models/job.model.js";
import { Recommendation } from "../../models/recommendation.model.js";
import { Resume } from "../../models/resume.js";
import { getJobRecommendations } from "../resume/resume.controller.js";

export const postJob = async(req, res) => {
    try {
        const {title, description, requirement, salary, jobType, experience, position, location, companyId} = req.body
        const userId = req.id;
        
        if(!title) {
            throw new Error("Please provide title")
        }
        if(!description) {
            throw new Error("Please provide description")
        }
        if(!requirement) {
            throw new Error("Please provide requirement")
        }
        if(!salary) {
            throw new Error("Please provide salary")
        }
        if(!jobType) {
            throw new Error("Please provide jobType")
        }
        if(!experience) {
            throw new Error("Please provide experience")
        }
        if(!position) {
            throw new Error("Please provide position")
        }
        
        const job = await Job.create({
            title, 
            description, 
            requirement: requirement.split(","),
            salary: Number(salary), 
            type: jobType, 
            experienceLevel: experience,
            position,
            company: companyId,
            location,
            created_by: userId
        })
        const resumes = await Resume.find().populate('user')

        for(const resume of resumes) {
            const recommendations = await getJobRecommendations(resume)
            const existing = recommendations.find((r)=> r.job._id.toString() === job._id.toString())
            if(existing && existing.score >= 50) {
                await Recommendation.create({
                    user: resume.user._id,
                    resume : resume._id,
                    job:job._id,
                    score:existing.score,
                    matchingReason:existing.matchingReason,
                });
            }
        }
        
        return res.status(201).json({
            message: "Job Created Successfully!",
            job,
            error: false,
            success: true
        })
    } catch(err) {
        res.status(400).json({  
            message: err.message || err,
            error: true,
            success: false,
        })
    }
}