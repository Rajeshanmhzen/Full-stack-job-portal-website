import Job from "../../models/job.model.js";

export const searchjobs = async (req, res) => {
  const {
    q = "",
    location = "",
    type,
    minSalary,
    maxSalary,
    page = 1,
    limit = 20,
    sort = "-createdAt",
  } = req.query;

  // Prepare search regex for case-insensitive matching
  const searchRegex = new RegExp(q, "i");

  // Build dynamic filters
  const filter = {
    $and: [
      q && {
        $or: [
          { title: { $regex: searchRegex } },
          { requirement: { $elemMatch: { $regex: searchRegex } } }
        ]
      },
      location && { location: new RegExp(location, "i") },
      type && { type },
      minSalary && { salary: { $gte: +minSalary } },
      maxSalary && { salary: { $lte: +maxSalary } },
    ].filter(Boolean),
  };

  try {
    const jobs = await Job.find(filter)
      .sort(sort)
      .skip((page - 1) * parseInt(limit))
      .limit(parseInt(limit));

    const total = await Job.countDocuments(filter);

    res.json({
      jobs,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ message: err.message });
  }
};
