export const USER_API_END_POINT = "http://localhost:8081/api/v1";
export const JOB_API_END_POINT = "http://localhost:8081/api/v1/job";
export const APPLICATION_API_END_POINT = "http://localhost:8081/api/v1/application";
export const RESUME_API_END_POINT = "http://localhost:8081/api/v1/resume";
export const COMPANY_API_END_POINT = "http://localhost:8081/api/v1/company";
export const SERVER_BASE_URL = "http://localhost:8081";
export const NOTIFICATION_API_END_POINT  = "http://localhost:8081/api/v1/notification"