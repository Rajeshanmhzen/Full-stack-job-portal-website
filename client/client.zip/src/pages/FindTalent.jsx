import { Divider } from '@mantine/core'
import Searchbar from "../features/jobs/SearchBar"

const FindTalent = () => {
  return (
    <div className='min-h-[90%] mt-10 '>
<Searchbar/>
        
    </div>
  )
}

export default FindTalent